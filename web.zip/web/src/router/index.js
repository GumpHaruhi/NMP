import { createRouter, createWebHistory } from 'vue-router'
const routes = [
    {
        path: '/',
        name: 'Home',
        component: () => import('@/views/Home.vue'),
        meta: { title: '首页' }
    },
    {
        path: '/player',
        name: 'Player',
        component: () => import('@/views/Player.vue'),
        meta: { title: '播放器' }
    },
    {
        path: '/profile',
        name: 'Profile',
        component: () => import('@/views/Profile.vue'),
        meta: { title: '个人主页' }
    },
    {
        path: '/playlist/:id',
        name: 'PlaylistDetail',
        component: () => import('../views/PlayListDetail.vue'), // 注意组件路径和名称
        props: true,
        meta: {
            title: '歌单详情 - NMP音乐播放器',
            requiresAuth: false,
            keepAlive: true
        }
    },
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

export default router