<template>
  <div class="player-page">
    <!-- 背景模糊层 -->
    <div class="player-background" :style="backgroundStyle"></div>

    <!-- 返回按钮 -->
    <button class="back-btn" @click="goBack">
      <ArrowLeftIcon class="back-icon" />
    </button>

    <!-- 播放器内容 -->
    <div class="player-content">
      <!-- 歌曲封面 -->
      <div class="cover-section">
        <div class="album-cover" :style="coverStyle" :class="{ rotating: isPlaying }">
          <div v-if="!currentSong?.coverUrl" class="cover-placeholder">
            <MusicIcon class="placeholder-icon" />
          </div>
        </div>
      </div>

      <!-- 歌曲信息 -->
      <div class="song-info">
        <h1 class="song-title">{{ currentSong?.title || '选择一首歌曲' }}</h1>
        <p class="song-artist">{{ currentSong?.singer || '暂无播放' }}</p>
      </div>

      <!-- 进度条 -->
      <div class="progress-section">
        <div class="progress-bar" @click="handleProgressClick" ref="progressBar">
          <div class="progress-track"></div>
          <div class="progress-fill" :style="{ width: progress + '%' }"></div>
        </div>
        <div class="time-display">
          <span class="current-time">{{ formatTime(currentTime) }}</span>
          <span class="total-time">{{ formatTime(duration) }}</span>
        </div>
      </div>

      <!-- 播放控制 -->
      <div class="controls-section">
        <div class="control-buttons">
          <button class="control-btn" @click="togglePlayMode" :title="playModeText">
            <RepeatIcon v-if="playMode === 'loop'" class="control-icon" />
            <ShuffleIcon v-else-if="playMode === 'random'" class="control-icon" />
            <SequentialIcon v-else class="control-icon" />
          </button>

          <button class="control-btn" @click="prevSong" title="上一首">
            <PrevIcon class="control-icon" />
          </button>

          <button class="play-pause-btn" @click="togglePlay" :title="isPlaying ? '暂停' : '播放'">
            <PlayIcon v-if="!isPlaying" class="play-pause-icon" />
            <PauseIcon v-else class="play-pause-icon" />
          </button>

          <button class="control-btn" @click="nextSong" title="下一首">
            <NextIcon class="control-icon" />
          </button>

          <button class="control-btn" @click="toggleLike" :title="isLiked ? '取消喜欢' : '喜欢'">
            <HeartIcon class="control-icon" :class="{ liked: isLiked }" />
          </button>
        </div>
      </div>
    </div>

    <!-- 底部播放栏（与全局底栏位置相同） -->
    <div class="player-bottom-bar">
      <div class="bottom-content">
        <div class="song-info">
          <div class="cover-image" :style="coverStyle">
            <div v-if="!currentSong?.coverUrl" class="cover-placeholder">
              <MusicIcon class="placeholder-icon" />
            </div>
          </div>
          <div class="song-details">
            <div class="song-title">{{ currentSong?.title || '暂无播放' }}</div>
            <div class="song-artist">{{ currentSong?.singer || '选择一首歌曲开始播放' }}</div>
          </div>
        </div>

        <div class="player-controls">
          <button class="control-btn" @click="prevSong" :disabled="!currentSong">
            <PrevIcon class="control-icon" />
          </button>

          <button class="play-pause-btn" @click="togglePlay" :disabled="!currentSong">
            <PlayIcon v-if="!isPlaying" class="play-pause-icon" />
            <PauseIcon v-else class="play-pause-icon" />
          </button>

          <button class="control-btn" @click="nextSong" :disabled="!currentSong">
            <NextIcon class="control-icon" />
          </button>
        </div>

        <div class="time-display">
          <span class="current-time">{{ formatTime(currentTime) }}</span>
          <span class="time-separator">/</span>
          <span class="total-time">{{ formatTime(duration) }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import { useMusicStore } from '@/stores/musicStore'

// 图标组件
import ArrowLeftIcon from '@/assets/icons/ArrowLeftIcon.vue'
import MusicIcon from '@/assets/icons/MusicIcon.vue'
import PlayIcon from '@/assets/icons/PlayIcon.vue'
import PauseIcon from '@/assets/icons/PauseIcon.vue'
import PrevIcon from '@/assets/icons/PrevIcon.vue'
import NextIcon from '@/assets/icons/NextIcon.vue'
import RepeatIcon from '@/assets/icons/RepeatIcon.vue'
import ShuffleIcon from '@/assets/icons/ShuffleIcon.vue'
import SequentialIcon from '@/assets/icons/SequentialIcon.vue'
import HeartIcon from '@/assets/icons/HeartIcon.vue'

const router = useRouter()
const musicStore = useMusicStore()

// 从store获取数据和方法
const {
  currentSong,
  isPlaying,
  currentTime,
  duration,
  playMode,
  isLiked,
  togglePlay,
  prevSong,
  nextSong,
  setCurrentTime,
  setPlayMode,
  likeSong,
  dislikeSong
} = musicStore

// Refs
const progressBar = ref(null)

// 计算属性
const progress = computed(() => {
  return duration.value > 0 ? (currentTime.value / duration.value) * 100 : 0
})

const coverStyle = computed(() => {
  if (currentSong.value?.coverUrl) {
    return {
      backgroundImage: `url(${currentSong.value.coverUrl})`
    }
  }
  return {}
})

const backgroundStyle = computed(() => {
  if (currentSong.value?.coverUrl) {
    return {
      backgroundImage: `url(${currentSong.value.coverUrl})`
    }
  }
  return {
    backgroundColor: '#e74c3c'
  }
})

const playModeText = computed(() => {
  switch (playMode.value) {
    case 'loop': return '循环播放'
    case 'random': return '随机播放'
    default: return '顺序播放'
  }
})

// 方法
const goBack = () => {
  router.back()
}

const togglePlayMode = () => {
  const modes = ['sequential', 'loop', 'random']
  const currentIndex = modes.indexOf(playMode.value)
  const nextIndex = (currentIndex + 1) % modes.length
  setPlayMode(modes[nextIndex])
}

const toggleLike = () => {
  if (!currentSong.value) return
  if (isLiked.value) {
    dislikeSong(currentSong.value.id)
  } else {
    likeSong(currentSong.value.id)
  }
}

const handleProgressClick = (event) => {
  if (!currentSong.value || !progressBar.value) return

  const rect = progressBar.value.getBoundingClientRect()
  const clickX = event.clientX - rect.left
  const width = rect.width
  const percentage = (clickX / width) * 100
  const newTime = (percentage / 100) * duration.value
  setCurrentTime(Math.max(0, Math.min(duration.value, newTime)))
}

const formatTime = (seconds) => {
  if (!seconds) return '0:00'
  const mins = Math.floor(seconds / 60)
  const secs = Math.floor(seconds % 60)
  return `${mins}:${secs.toString().padStart(2, '0')}`
}

// 键盘快捷键
const handleKeyPress = (event) => {
  switch (event.code) {
    case 'Space':
      event.preventDefault()
      togglePlay()
      break
    case 'ArrowLeft':
      event.preventDefault()
      setCurrentTime(Math.max(0, currentTime.value - 10))
      break
    case 'ArrowRight':
      event.preventDefault()
      setCurrentTime(Math.min(duration.value, currentTime.value + 10))
      break
    case 'Escape':
      goBack()
      break
  }
}

// 生命周期
onMounted(() => {
  document.addEventListener('keydown', handleKeyPress)
})

onUnmounted(() => {
  document.removeEventListener('keydown', handleKeyPress)
})
</script>

<style scoped>
.player-page {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: #000;
  z-index: 1000;
}

.player-background {
  position: absolute;
  top: -20px;
  left: -20px;
  right: -20px;
  bottom: -20px;
  background-size: cover;
  background-position: center;
  filter: blur(20px) brightness(0.6);
  transform: scale(1.1);
}

.back-btn {
  position: absolute;
  top: 20px;
  left: 20px;
  background: rgba(255, 255, 255, 0.2);
  border: none;
  border-radius: 50%;
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  z-index: 10;
  transition: all 0.3s ease;
}

.back-btn:hover {
  background: rgba(255, 255, 255, 0.3);
  transform: scale(1.1);
}

.back-icon {
  width: 20px;
  height: 20px;
  color: white;
}

.player-content {
  position: relative;
  height: calc(100% - 60px);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 40px;
  color: white;
  text-align: center;
}

.cover-section {
  margin-bottom: 40px;
}

.album-cover {
  width: 300px;
  height: 300px;
  border-radius: 20px;
  background-size: cover;
  background-position: center;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
  position: relative;
  overflow: hidden;
}

.album-cover.rotating {
  animation: rotate 20s linear infinite;
}

.cover-placeholder {
  width: 100%;
  height: 100%;
  background: linear-gradient(135deg, #e74c3c, #3498db);
  display: flex;
  align-items: center;
  justify-content: center;
}

.placeholder-icon {
  width: 80px;
  height: 80px;
  color: white;
  opacity: 0.8;
}

.song-info {
  margin-bottom: 40px;
  max-width: 500px;
}

.song-title {
  font-size: 32px;
  font-weight: 700;
  margin-bottom: 8px;
  text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
}

.song-artist {
  font-size: 18px;
  opacity: 0.9;
  text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
  margin: 0;
}

.progress-section {
  width: 100%;
  max-width: 500px;
  margin-bottom: 40px;
}

.progress-bar {
  width: 100%;
  height: 4px;
  background: rgba(255, 255, 255, 0.3);
  border-radius: 2px;
  cursor: pointer;
  margin-bottom: 8px;
}

.progress-track {
  width: 100%;
  height: 100%;
}

.progress-fill {
  height: 100%;
  background: white;
  border-radius: 2px;
  transition: width 0.1s ease;
}

.time-display {
  display: flex;
  justify-content: space-between;
  font-size: 14px;
  opacity: 0.8;
}

.controls-section {
  margin-bottom: 30px;
}

.control-buttons {
  display: flex;
  align-items: center;
  gap: 20px;
}

.control-btn {
  background: rgba(255, 255, 255, 0.2);
  border: none;
  border-radius: 50%;
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.3s ease;
}

.control-btn:hover {
  background: rgba(255, 255, 255, 0.3);
  transform: scale(1.1);
}

.control-icon {
  width: 20px;
  height: 20px;
  color: white;
}

.control-icon.liked {
  color: #e74c3c;
}

.play-pause-btn {
  background: white;
  border: none;
  border-radius: 50%;
  width: 60px;
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.3s ease;
}

.play-pause-btn:hover {
  transform: scale(1.1);
}

.play-pause-icon {
  width: 24px;
  height: 24px;
  color: #e74c3c;
}

/* 底部播放栏（与全局底栏相同位置和样式） */
.player-bottom-bar {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  height: 60px;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-top: 1px solid rgba(255, 255, 255, 0.2);
  z-index: 5;
}

.bottom-content {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 100%;
  padding: 0 20px;
  gap: 20px;
}

.bottom-content .song-info {
  display: flex;
  align-items: center;
  gap: 12px;
  flex: 1;
  margin: 0;
}

.bottom-content .cover-image {
  width: 40px;
  height: 40px;
  border-radius: 6px;
  background-size: cover;
  background-position: center;
}

.bottom-content .song-title {
  font-size: 14px;
  color: #333;
  margin: 0;
  text-shadow: none;
}

.bottom-content .song-artist {
  font-size: 12px;
  color: #666;
  margin: 0;
  text-shadow: none;
}

.bottom-content .player-controls {
  display: flex;
  align-items: center;
  gap: 15px;
  flex-shrink: 0;
}

.bottom-content .control-btn {
  background: #f8f9fa;
  color: #333;
}

.bottom-content .control-btn:hover {
  background: #007bff;
  color: white;
}

.bottom-content .play-pause-btn {
  background: #007bff;
}

.bottom-content .play-pause-icon {
  color: white;
}

.bottom-content .time-display {
  font-size: 12px;
  color: #666;
  flex-shrink: 0;
  min-width: 80px;
  justify-content: flex-end;
}

@keyframes rotate {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

/* 响应式设计 */
@media (max-width: 768px) {
  .player-content {
    padding: 20px;
  }

  .album-cover {
    width: 200px;
    height: 200px;
  }

  .song-title {
    font-size: 24px;
  }

  .song-artist {
    font-size: 16px;
  }

  .control-buttons {
    gap: 15px;
  }
}

@media (max-width: 480px) {
  .player-content {
    padding: 16px;
  }

  .album-cover {
    width: 150px;
    height: 150px;
  }

  .song-title {
    font-size: 20px;
  }

  .control-buttons {
    gap: 10px;
  }

  .control-btn {
    width: 36px;
    height: 36px;
  }

  .play-pause-btn {
    width: 50px;
    height: 50px;
  }

  .bottom-content {
    padding: 0 15px;
    gap: 15px;
  }

  .bottom-content .cover-image {
    width: 36px;
    height: 36px;
  }

  .bottom-content .song-title {
    font-size: 13px;
  }

  .bottom-content .song-artist {
    font-size: 11px;
  }

  .bottom-content .time-display {
    display: none;
  }
}
</style>